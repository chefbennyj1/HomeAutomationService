﻿using HomeAutomationService.Alexa;
using HomeAutomationService.Helpers;
using HomeAutomationService.Xbox;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace HomeAutomationService
{
    public class ValuesController : ApiController
    {
        private readonly Func<object, bool> isNullOrEmpty = o => o.Equals(null);

        private static readonly Func<object, AlexaRequest> SerializeAlexaRequest = a =>
            JsonConvert.DeserializeObject<AlexaRequest>(JObject.Parse(a.ToString()).ToString());

        public object Get()
        {
            return "ApiControlller";
        }

        public object Get(int id)
        {
            var result = new HttpResponseMessage(HttpStatusCode.OK);

            switch (id)
            {

                case 1:

                    return result;

                case 2:

                    return result;

                default:

                    return result;
            }
        }

        [Route("XboxController/values")]
        public async Task<IHttpActionResult> Post([FromBody] object value)
        {
            AlexaRequest alexaRequest = null;

            try { alexaRequest = SerializeAlexaRequest(value); } catch { }

            if (isNullOrEmpty(alexaRequest)) return Ok(new HttpResponseMessage(HttpStatusCode.OK));

            var alexa = new AlexaApi();

            if (alexa.LaunchRequest(alexaRequest) || 
                Equals(alexa.RequestName(alexaRequest), "TurnOn") || 
                Equals(alexa.RequestName(alexaRequest), "AMAZON.ActivateAction<object@PlaybackMode>"))  // asking to "turn on" 
            {
                

                ConsoleHelper.Write("Alexa Request - Xbox One Start up", ConsoleHelper.AppMessage.Alexa);

                alexa.PostDirectiveResponseAsync(alexaRequest, string.Format("Connecting to  Xbox One. {0} Just a moment.",
                    AlexaApi.AlexaInsertStrengthBreak(AlexaApi.StrengthBreaks.weak)));

                await SmartGlass.Device.PowerOnAsync(XboxOneApi.LiveId);
                
                alexa.PostDirectiveResponseAsync(alexaRequest, string.Format("Signing into  Xbox One. {0}",
                   AlexaApi.AlexaInsertStrengthBreak(AlexaApi.StrengthBreaks.weak)));

                await Task.Delay(1000);
                
                return Ok(AlexaApi.ResponseBuilder("Xbox One is ready."));
            }

            if (alexa.CanFulfillIntentRequest(alexaRequest))
            {
                Console.WriteLine(DateTime.Now + ":   CanFulfillIntentRequest ");
            }

            if (!alexa.SessionEndedRequest(alexaRequest))
            {
                switch (alexa.RequestName(alexaRequest))
                {
                    case "AMAZON.DeactivateAction<object@Thing>":
                    case "TurnOff":
                        try
                        {
                            await SmartGlass.Device.PingAsync("192.168.2.10");
                        }
                        catch (Exception) {
                            return Ok(AlexaApi.ResponseBuilder(string.Format("{0} Xbox One Console is currently off.", 
                                AlexaSynthesisResponseLibrary.GetResponse(HumanizedResponseType.apologetic))));
                        }

                        await Task.Run(async () => await XboxOneApi.XboxOneClient.PowerOffAsync());

                        alexa.PostDirectiveResponseAsync(alexaRequest, "OK,  shutting down xbox one.");

                        ConsoleHelper.Write("Alexa Request - Xbox One Shut down", ConsoleHelper.AppMessage.Alexa);

                        await Task.Delay(2000);

                        alexa.PostDirectiveResponseAsync(alexaRequest, string.Format("Waiting for Xbox One. {0}",
                                         AlexaApi.AlexaInsertStrengthBreak(AlexaApi.StrengthBreaks.weak)));

                        await Task.Delay(3000);

                        return Ok(AlexaApi.ResponseBuilder("OK. Xbox is shut down."));

                    case "StartEmby":

                        await Task.Factory.StartNew(XboxOneApi.StartEmby);
                        ConsoleHelper.Write("Alexa Request - Start Emby Theater", ConsoleHelper.AppMessage.Alexa);
                        return Ok(AlexaApi.ResponseBuilder(string.Format("{0}. Starting Emby Theater on Xbox One.",
                            AlexaSynthesisResponseLibrary.GetResponse(HumanizedResponseType.compliance)), true));

                    case "StartLiveTV":

                        await Task.Run(() => XboxOneApi.StartLiveTV());
                        ConsoleHelper.Write("Alexa Request - Start Live TV", ConsoleHelper.AppMessage.Alexa);
                        return Ok(AlexaApi.ResponseBuilder(string.Format("{0}. Starting live TV on Xbox One",
                            AlexaSynthesisResponseLibrary.GetResponse(HumanizedResponseType.compliance)), true));

                    case "StartGame":

                        await Task.Run(() => XboxOneApi.StartGame(alexaRequest.request.intent.slots.GameTitle.value));
                        ConsoleHelper.Write(string.Format("Alexa Request - Start {0}", alexaRequest.request.intent.slots.GameTitle.value), ConsoleHelper.AppMessage.Alexa);
                        return Ok(AlexaApi.ResponseBuilder(string.Format("{0}. Starting the game {1} on Xbox One",
                            AlexaSynthesisResponseLibrary.GetResponse(HumanizedResponseType.compliance),
                            alexaRequest.request.intent.slots.GameTitle.value, true)));

                    case "StartApp":

                        await Task.Run(() => XboxOneApi.StartApp(alexaRequest.request.intent.slots.AppTitle.value));
                        ConsoleHelper.Write(string.Format("Alexa Request - Start {0}", alexaRequest.request.intent.slots.AppTitle.value),ConsoleHelper.AppMessage.Alexa);
                        //var check = false;
                        //while (!check)
                        //{
                        //    if(Equals(XboxTitleDictionary.Titles[XboxOneApi.NowViewingTitleId].ToLower(), alexaRequest.request.intent.slots.AppTitle.value.ToLower())){
                        //        check = true;
                        //    }
                        //}
                        return Ok(AlexaApi.ResponseBuilder(string.Format("{0}. Starting {1} on Xbox One",
                            AlexaSynthesisResponseLibrary.GetResponse(HumanizedResponseType.compliance),
                            alexaRequest.request.intent.slots.AppTitle.value, true)));

                    case "AMAZON.YesIntent":
                    case "AMAZON.NoIntent":

                        return Ok(AlexaApi.ResponseBuilder("OK.", true));

                        //case "OpenComputerApp":

                        //case "ComputerLabStartup":
                        //    Factory.HttpClient.GET(
                        //        "http://192.168.2.15:3480/data_request?id=action&output_format=xml&DeviceNum=117&serviceId=urn:upnp-org:serviceId:SwitchPower1&action=SetTarget&newTargetValue=1");
                        //    return AlexaApi.ResponseBuilder(string.Format("{0} Starting up Computer Lab. {1} What are we doing today sir?", 
                        //        AlexaSynthesisResponseLibrary.GetResponse(HumanizedResponseType.compliance), 
                        //        AlexaApi.AlexaInsertStrengthBreak(AlexaApi.StrengthBreaks.weak)), false);


                }
            }
            return Ok(new HttpResponseMessage(HttpStatusCode.OK));
        }
    }
}

