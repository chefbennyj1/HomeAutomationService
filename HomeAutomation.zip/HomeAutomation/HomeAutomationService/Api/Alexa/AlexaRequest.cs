﻿using System;
using System.Collections.Generic;

namespace HomeAutomationService.Alexa 
{
    public class Application 
    {
        public string applicationId { get; set; }
    }



    public class User 
    {
        public string userId { get; set; }
    }



    public class Session 
    {
        public bool @new { get; set; }
        public string sessionId { get; set; }
        public Application application { get; set; }
        public User user { get; set; }
    }



    public class AudioPlayer 
    {
        public string playerActivity { get; set; }
    }

    
    public class Application2 
    {
        public string applicationId { get; set; }
    }

  

    public class User2 
    {
        public string userId { get; set; }
    }

   

    public class AudioPlayer2
    {
    }

   

    public class SupportedInterfaces 
    {
        public AudioPlayer2 AudioPlayer { get; set; }
    }

  

    public class Device
    { 
        public string deviceId { get; set; }
        public SupportedInterfaces supportedInterfaces { get; set; }
    }

  

    public class System 
    {
        public Application2 application { get; set; }
        public User2 user { get; set; }
        public Device device { get; set; }
        public string apiEndpoint { get; set; }
        public string apiAccessToken { get; set; }
    }

   

    public class Context 
    {
        public AudioPlayer AudioPlayer { get; set; }
        public System System { get; set; }
    }

  

    public class Intent
    {
        public string name { get; set; }
        public Slots slots { get; set; }
        public string confirmationStatus { get; set; }
    }

   

    public class Slots
    {
        public SlotData GameTitle { get; set; }
        public SlotData AppTitle { get; set; }
    }

    public class SlotData
    {
        public string name { get; set; }
        public string value { get; set; }
        public string type { get; set; }
        public bool confirmationRequired { get; set; }
        public bool elicitationRequired { get; set; }
    }

    public class Request
    {
        public string type { get; set; }
        public string requestId { get; set; }
        public DateTime timestamp { get; set; }
        public string locale { get; set; }
        public Intent intent { get; set; }
    }

  

    public class AlexaRequest
    {
        public string version { get; set; }
        public Session session { get; set; }
        public Context context { get; set; }
        public Request request { get; set; }
    }
}