﻿using System.Collections.Generic;

namespace HomeAutomationService.Xbox
{
    public static class XboxTitleDictionary
    {
        public static readonly Dictionary<uint, string> Titles = new Dictionary<uint, string>
        {
            {1945785393,                                 "Emby" },
            {327370029 ,                                  "Netflix" },
            {371594669 ,                                  "TV" },
            {750323071,                                   "Dashboard" },
            {368200277,                                   "Dashboard" },
            {1856820720 ,                                "Skype" },
            { 591405932,                                  "Red Dead Redemption 2" },
            {122001257,                                   "YouTube"}
        };
    }
}
