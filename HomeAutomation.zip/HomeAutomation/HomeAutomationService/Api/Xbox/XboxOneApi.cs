﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using HomeAutomationService.Helpers;
using HomeAutomationService.MachineLearning;
using SmartGlass;

namespace HomeAutomationService.Xbox
{
    public static class XboxOneApi
    {
        public static SmartGlassClient XboxOneClient { get; private set; }
        private static IEnumerable<Device> XboxDeviceInfo { get; set; }
        private static uint NowViewingTitleId { get; set; }
        private static Timer XboxStateMonitor { get; set; }

        public enum XboxState
        {
            ON = 1,
            OFF = 0
        }

        public static XboxState State { get; set; }

        private static async void XboxStateMonitorDelegate(object sender)
        {
            XboxStateMonitor.Change(Timeout.Infinite, Timeout.Infinite);
            try
            {
                var ping = await Device.PingAsync("192.168.2.10");

                if (Equals(XboxOneClient, null)) BuildXboxOneClient(CreateStateMonitor: false);

                if (Equals(State, XboxState.OFF))
                {
                    State = XboxState.ON;
                    ConsoleHelper.Write(string.Format("{0} Console is ON", ping.Name), ConsoleHelper.AppMessage.Xbox);
                   // AutomationJSONDictionary.AppendXboxValues(true);               
                }
            }
            catch (Exception) //The ping exception is because the xbox is off and there is nothing to hit at the endpoint
            {
                if(Equals(State, XboxState.ON))
                {
                    ConsoleHelper.Write(string.Format("Xbox One Console is OFF."), ConsoleHelper.AppMessage.Xbox);
                    XboxOneClient = null;
                    NowViewingTitleId = 0;
                    //AutomationJSONDictionary.AppendXboxValues(false);
                }               

                State = XboxState.OFF;
            }
            XboxStateMonitor.Change(1000, 1000);
        }

        public static async void BuildXboxOneClient(bool CreateStateMonitor)
        {
            //Create the State monitor Timer and return immediately
            if (CreateStateMonitor)
            {
                XboxStateMonitor = new Timer(XboxStateMonitorDelegate);
                XboxStateMonitor.Change(0, 1000);
                return;
            }

            try
            {
                XboxDeviceInfo = Device.DiscoverAsync().Result;  
            }
            catch (Exception)
            {
            }

            try
            {
                XboxOneClient = await SmartGlassClient.ConnectAsync(XboxDeviceInfo.FirstOrDefault().Address.ToString());
                XboxOneClient.ConsoleStatusChanged += XboxOneClient_ConsoleStatusChanged;
                //ConsoleHelper.Write("======= Initalizing Xbox One Connections ========", ConsoleHelper.AppMessage.Xbox);
                ConsoleHelper.Write(string.Format("{0} Xbox One Console(s) found on network", XboxDeviceInfo.Count()), ConsoleHelper.AppMessage.Xbox);
                ConsoleHelper.Write(string.Format("{0} Connected", XboxDeviceInfo.FirstOrDefault().Name), ConsoleHelper.AppMessage.Xbox);
                ConsoleHelper.Write(string.Format("{0} Live ID {1}", XboxDeviceInfo.FirstOrDefault().Name,
                    XboxDeviceInfo.FirstOrDefault().Certificate.SubjectDN.GetValueList()[0]), ConsoleHelper.AppMessage.Xbox); //Live ID
                ConsoleHelper.Write(string.Format("Waiting for Xbox One Events..."), ConsoleHelper.AppMessage.Xbox);
            }
            catch (Exception)
            {
                ConsoleHelper.Write("Attempting Xbox One Connection.", ConsoleHelper.AppMessage.Xbox);
            }
        }

        private static void XboxOneClient_ConsoleStatusChanged(object sender, ConsoleStatusChangedEventArgs e)
        {
            foreach (var title in e.Status.ActiveTitles)
            {
                if (Equals(NowViewingTitleId, title.TitleId) || Equals(title.TitleId, 368200277)) return;
                try
                {
                    ConsoleHelper.Write(string.Format("Active App/Game: {0}", 
                        XboxTitleDictionary.Titles[title.TitleId]), ConsoleHelper.AppMessage.Xbox);
                }
                catch (Exception)
                {
                    ConsoleHelper.Write(string.Format("{0} - {1}", title.TitleId, "New Title Id found!"), ConsoleHelper.AppMessage.Xbox);
                }
                NowViewingTitleId = title.TitleId;
                return;
            }

        }


        public static async void StartEmby()
        {
            try
            {
                await XboxOneClient.LaunchTitleByTitleIdAsync(1945785393);
            }
            catch
            {
            }
        }

        public static async void StartApp(string titleName)
        {
            uint titleId = 0;

            foreach (var title in XboxTitleDictionary.Titles)
                if (Equals(title.Value.ToLower(), titleName.ToLower()))
                    titleId = title.Key;
            try
            {
                await XboxOneClient.LaunchTitleByTitleIdAsync(titleId);
            }
            catch (Exception e)
            {
                ConsoleHelper.Write(e.Message, ConsoleHelper.AppMessage.Error);
            }
        }

        public static async void StartGame(string titleName)
        {
            uint titleId = 0;
            foreach (var title in XboxTitleDictionary.Titles)
                if (string.Equals(title.Value, titleName, StringComparison.CurrentCultureIgnoreCase))
                    titleId = title.Key;
            try
            {
                await XboxOneClient.LaunchTitleByTitleIdAsync(titleId);
            }
            catch (Exception e)
            {
                ConsoleHelper.Write(e.Message, ConsoleHelper.AppMessage.Error);
            }
        }

        public static async void StartLiveTV()
        {
            try
            {
                await XboxOneClient.LaunchTitleByTitleIdAsync(371594669);
            }
            catch (Exception e)
            {
                ConsoleHelper.Write(e.Message, ConsoleHelper.AppMessage.Error);
            }
        }

        public static bool IsXboxOff()
        {
            ConsoleHelper.Write("Checking Xbox One network status is off:", ConsoleHelper.AppMessage.Xbox);
            var alive = true;
            while (alive)

                if (State == XboxState.OFF)
                    alive = false;
            return true;
        }

        public const string LiveId = "FD00282F9CBB11EE";
    }
}
