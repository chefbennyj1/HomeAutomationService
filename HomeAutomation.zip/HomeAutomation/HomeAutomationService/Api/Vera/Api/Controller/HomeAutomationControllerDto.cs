﻿using System.Collections.Generic;

namespace HomeAI2.HomeAutomation.Api.Controller
{
    // ReSharper disable InconsistentNaming
    // ReSharper disable ClassNeverInstantiated.Global
    // ReSharper disable UnusedMember.Global
    // ReSharper disable UnusedAutoPropertyAccessor.Global
    // ReSharper disable TooManyArguments
    // ReSharper disable MaximumChainedReferences

    public class State
    {
        public string service { get; set; }
        public string variable { get; set; }
        public string value { get; set; }
        public int id { get; set; }
        public string pnp { get; set; }
    }

    public class Service1
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service2
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service3
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service4
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service5
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service6
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service7
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service8
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service9
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service10
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service11
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service12
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service13
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service14
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service15
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service16
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service17
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service18
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service19
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service20
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service21
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service22
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service23
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service24
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service25
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service26
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service27
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service28
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service29
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service30
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service31
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service32
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service33
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service34
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service35
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service36
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service37
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service38
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service39
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service40
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service41
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service42
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service43
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service44
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service45
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service46
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service47
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service48
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service49
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service50
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service51
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service52
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service53
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service54
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service55
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service56
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service57
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service58
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service59
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service60
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service61
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service62
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service63
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service64
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service65
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service66
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service67
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service68
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service69
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service70
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service71
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service72
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service73
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service74
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service75
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service76
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service77
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service78
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service79
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service80
    {
        public string service { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
        public string serviceType { get; set; }
    }

    public class Service81
    {
        public string service { get; set; }
        public string serviceType { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
    }

    public class Service82
    {
        public string service { get; set; }
        public string serviceType { get; set; }
        public string ControlURL { get; set; }
        public string EventURL { get; set; }
    }

    public class ControlURLs
    {
        public Service1 service_1 { get; set; }
        public Service2 service_2 { get; set; }
        public Service3 service_3 { get; set; }
        public Service4 service_4 { get; set; }
        public Service5 service_5 { get; set; }
        public Service6 service_6 { get; set; }
        public Service7 service_7 { get; set; }
        public Service8 service_8 { get; set; }
        public Service9 service_9 { get; set; }
        public Service10 service_10 { get; set; }
        public Service11 service_11 { get; set; }
        public Service12 service_12 { get; set; }
        public Service13 service_13 { get; set; }
        public Service14 service_14 { get; set; }
        public Service15 service_15 { get; set; }
        public Service16 service_16 { get; set; }
        public Service17 service_17 { get; set; }
        public Service18 service_18 { get; set; }
        public Service19 service_19 { get; set; }
        public Service20 service_20 { get; set; }
        public Service21 service_21 { get; set; }
        public Service22 service_22 { get; set; }
        public Service23 service_23 { get; set; }
        public Service24 service_24 { get; set; }
        public Service25 service_25 { get; set; }
        public Service26 service_26 { get; set; }
        public Service27 service_27 { get; set; }
        public Service28 service_28 { get; set; }
        public Service29 service_29 { get; set; }
        public Service30 service_30 { get; set; }
        public Service31 service_31 { get; set; }
        public Service32 service_32 { get; set; }
        public Service33 service_33 { get; set; }
        public Service34 service_34 { get; set; }
        public Service35 service_35 { get; set; }
        public Service36 service_36 { get; set; }
        public Service37 service_37 { get; set; }
        public Service38 service_38 { get; set; }
        public Service39 service_39 { get; set; }
        public Service40 service_40 { get; set; }
        public Service41 service_41 { get; set; }
        public Service42 service_42 { get; set; }
        public Service43 service_43 { get; set; }
        public Service44 service_44 { get; set; }
        public Service45 service_45 { get; set; }
        public Service46 service_46 { get; set; }
        public Service47 service_47 { get; set; }
        public Service48 service_48 { get; set; }
        public Service49 service_49 { get; set; }
        public Service50 service_50 { get; set; }
        public Service51 service_51 { get; set; }
        public Service52 service_52 { get; set; }
        public Service53 service_53 { get; set; }
        public Service54 service_54 { get; set; }
        public Service55 service_55 { get; set; }
        public Service56 service_56 { get; set; }
        public Service57 service_57 { get; set; }
        public Service58 service_58 { get; set; }
        public Service59 service_59 { get; set; }
        public Service60 service_60 { get; set; }
        public Service61 service_61 { get; set; }
        public Service62 service_62 { get; set; }
        public Service63 service_63 { get; set; }
        public Service64 service_64 { get; set; }
        public Service65 service_65 { get; set; }
        public Service66 service_66 { get; set; }
        public Service67 service_67 { get; set; }
        public Service68 service_68 { get; set; }
        public Service69 service_69 { get; set; }
        public Service70 service_70 { get; set; }
        public Service71 service_71 { get; set; }
        public Service72 service_72 { get; set; }
        public Service73 service_73 { get; set; }
        public Service74 service_74 { get; set; }
        public Service75 service_75 { get; set; }
        public Service76 service_76 { get; set; }
        public Service77 service_77 { get; set; }
        public Service78 service_78 { get; set; }
        public Service79 service_79 { get; set; }
        public Service80 service_80 { get; set; }
        public Service81 service_81 { get; set; }
        public Service82 service_82 { get; set; }
    }

    public class Wakeup
    {
        public List<int> list { get; set; }
        public int lastKnown { get; set; }
    }

    public class Device
    {
        public int id { get; set; }
        public string name { get; set; }
        public string device_type { get; set; }
        public string device_file { get; set; }
        public List<State> states { get; set; }
        public object category_num { get; set; }
        public object subcategory_num { get; set; }
        public ControlURLs ControlURLs { get; set; }
        public object time_created { get; set; }
        public string invisible { get; set; }
        public string local_udn { get; set; }
        public object room { get; set; }
        public int? id_parent { get; set; }
        public object embedded { get; set; }
        public int? disabled { get; set; }
        public string impl_file { get; set; }
        public string manufacturer { get; set; }
        public string model { get; set; }
        public string altid { get; set; }
        public string ip { get; set; }
        public string mac { get; set; }
        public string device_json { get; set; }
        public List<string> poll { get; set; }
        public string onDashboard { get; set; }
        public string pnp { get; set; }
        public Wakeup wakeup { get; set; }
        public string username { get; set; }
        public string skip_view_emulation_popup { get; set; }
        public string password { get; set; }
        public string plugin { get; set; }
    }

    public class Room
    {
        public int id { get; set; }
        public string name { get; set; }
        public int section { get; set; }
    }

    public class Scene
    {
        public string name { get; set; }
        public int notification_only { get; set; }
        public string modeStatus { get; set; }
        public List<object> triggers { get; set; }
        public string users { get; set; }
        public int id { get; set; }
        public int Timestamp { get; set; }
        public int last_run { get; set; }
        public object room { get; set; }
        public string triggers_operator { get; set; }
        public List<object> groups { get; set; }
        public List<object> timers { get; set; }
        public int? paused { get; set; }
        public string lua { get; set; }
        public int? encoded_lua { get; set; }
        public string active_on_any { get; set; }
    }

    public class Section
    {
        public int id { get; set; }
        public string name { get; set; }
    }

    public class WeatherSettings
    {
        public string tempFormat { get; set; }
        public string weatherCountry { get; set; }
        public string weatherCity { get; set; }
    }

    public class IpRequest
    {
        public string mac { get; set; }
        public string ip { get; set; }
        public int date { get; set; }
    }

    public class File
    {
        public string SourceName { get; set; }
        public object SourcePath { get; set; }
        public string DestName { get; set; }
        public string DestPath { get; set; }
        public string Compress { get; set; }
        public string Encrypt { get; set; }
        public string Role { get; set; }
    }

    public class Device2
    {
        public string DeviceFileName { get; set; }
        public string DeviceType { get; set; }
        public string ImplFile { get; set; }
        public string Invisible { get; set; }
        public string CategoryNum { get; set; }
    }

    public class Lua
    {
        public string FileName { get; set; }
    }

    public class InstalledPlugins2
    {
        public string Version { get; set; }
        public string AllowMultiple { get; set; }
        public string Title { get; set; }
        public string Icon { get; set; }
        public string Instructions { get; set; }
        public string Hidden { get; set; }
        public string AutoUpdate { get; set; }
        public int RemoteFriendly { get; set; }
        public int SystemPlugin { get; set; }
        public string VersionMajor { get; set; }
        public string VersionMinor { get; set; }
        public object SupportedPlatforms { get; set; }
        public object MinimumVersion { get; set; }
        public object DevStatus { get; set; }
        public string Approved { get; set; }
        public int id { get; set; }
        public string OldVersion { get; set; }
        public int OldTimestamp { get; set; }
        public int timestamp { get; set; }
        public List<File> Files { get; set; }
        public List<Device2> Devices { get; set; }
        public List<Lua> Lua { get; set; }
    }

    public class User
    {
        public int id { get; set; }
        public string Name { get; set; }
        public int Level { get; set; }
        public int IsGuest { get; set; }
    }

    public class Nif
    {
        public int id { get; set; }
        public string nif { get; set; }
    }

    public class ZwaveBackup
    {
        public string homeid { get; set; }
        public int nodeid { get; set; }
        public List<Nif> nif { get; set; }
    }

    public class Geotag
    {
        public int PK_User { get; set; }
        public int id { get; set; }
        public int accuracy { get; set; }
        public int ishome { get; set; }
        public int notify { get; set; }
        public int radius { get; set; }
        public string address { get; set; }
        public string color { get; set; }
        public string latitude { get; set; }
        public string longitude { get; set; }
        public string name { get; set; }
        public object status { get; set; }
    }

    public class Usergeofence
    {
        public int iduser { get; set; }
        public List<Geotag> geotags { get; set; }
    }

    public class Label
    {
        public string lang_tag { get; set; }
        public string text { get; set; }
    }

    public class ControlGroup
    {
        public string id { get; set; }
        public string scenegroup { get; set; }
        public string isSingle { get; set; }
    }

    public class SceneGroup
    {
        public string id { get; set; }
        public string top { get; set; }
        public string left { get; set; }
        public string x { get; set; }
        public string y { get; set; }
    }

    public class Value
    {
        public string Min { get; set; }
        public string Max { get; set; }
    }

    public class Operand
    {
        public string Service { get; set; }
        public string Variable { get; set; }
        public Value Value { get; set; }
    }

    public class Trigger
    {
        public List<Operand> Operands { get; set; }
    }

    public class Action
    {
        public string action { get; set; }
        public string ActionArgument { get; set; }
        public string Target { get; set; }
    }

    public class Condition
    {
        public Trigger Trigger { get; set; }
        public List<Action> Actions { get; set; }
    }

    public class Tab
    {
        public Label Label { get; set; }
        public string Position { get; set; }
        public string TabType { get; set; }
        public int top_navigation_tab { get; set; }
        public List<object> Control { get; set; }
        public string ScriptName { get; set; }
        public string Function { get; set; }
        public List<ControlGroup> ControlGroup { get; set; }
        public List<SceneGroup> SceneGroup { get; set; }
        public List<Condition> Conditions { get; set; }
    }

    public class Arguments
    {
        public string NewModeTarget { get; set; }
        public string newLoadlevelTarget { get; set; }
        public string newTargetValue { get; set; }
        public string newArmedValue { get; set; }
    }

    public class Display
    {
        public string service { get; set; }
        public string variable { get; set; }
        public string value { get; set; }
    }

    public class Cmd1
    {
        public string label { get; set; }
        public string serviceId { get; set; }
        public string action { get; set; }
        public Arguments arguments { get; set; }
        public Display display { get; set; }
    }

    public class Arguments2
    {
        public string NewModeTarget { get; set; }
        public string newLoadlevelTarget { get; set; }
        public string newTargetValue { get; set; }
        public string newArmedValue { get; set; }
    }

    public class Display2
    {
        public string service { get; set; }
        public string variable { get; set; }
        public string value { get; set; }
    }

    public class Cmd2
    {
        public string label { get; set; }
        public string serviceId { get; set; }
        public string action { get; set; }
        public Arguments2 arguments { get; set; }
        public Display2 display { get; set; }
    }

    public class Arguments3
    {
        public string NewModeTarget { get; set; }
    }

    public class AllowedValueRange
    {
        public string minimum { get; set; }
        public string maximum { get; set; }
    }

    public class Argument1
    {
        public string dataType { get; set; }
        public string defaultValue { get; set; }
        public AllowedValueRange allowedValueRange { get; set; }
        public string prefix { get; set; }
        public string suffix { get; set; }
        public string name { get; set; }
    }

    public class ArgumentList
    {
        public Argument1 argument_1 { get; set; }
    }

    public class Display3
    {
        public string service { get; set; }
        public string variable { get; set; }
    }

    public class Cmd3
    {
        public string label { get; set; }
        public string serviceId { get; set; }
        public string action { get; set; }
        public Arguments3 arguments { get; set; }
        public ArgumentList argumentList { get; set; }
        public Display3 display { get; set; }
    }

    public class Arguments4
    {
        public string NewModeTarget { get; set; }
    }

    public class Cmd4
    {
        public string label { get; set; }
        public string serviceId { get; set; }
        public string action { get; set; }
        public Arguments4 arguments { get; set; }
    }

    public class Group1
    {
        public Cmd1 cmd_1 { get; set; }
        public Cmd2 cmd_2 { get; set; }
        public Cmd3 cmd_3 { get; set; }
        public Cmd4 cmd_4 { get; set; }
    }

    public class AllowedValueRange2
    {
        public string minimum { get; set; }
        public string maximum { get; set; }
    }

    public class Argument12
    {
        public string dataType { get; set; }
        public string defaultValue { get; set; }
        public AllowedValueRange2 allowedValueRange { get; set; }
        public string prefix { get; set; }
        public string suffix { get; set; }
        public string name { get; set; }
    }

    public class ArgumentList2
    {
        public Argument12 argument_1 { get; set; }
    }

    public class Cmd12
    {
        public string label { get; set; }
        public string serviceId { get; set; }
        public string action { get; set; }
        public ArgumentList2 argumentList { get; set; }
    }

    public class Group2
    {
        public Cmd12 cmd_1 { get; set; }
    }

    public class AllowedValueRange3
    {
        public string minimum { get; set; }
        public string maximum { get; set; }
    }

    public class Argument13
    {
        public string dataType { get; set; }
        public string defaultValue { get; set; }
        public AllowedValueRange3 allowedValueRange { get; set; }
        public string prefix { get; set; }
        public string suffix { get; set; }
        public string name { get; set; }
    }

    public class ArgumentList3
    {
        public Argument13 argument_1 { get; set; }
    }

    public class Cmd13
    {
        public string label { get; set; }
        public string serviceId { get; set; }
        public string action { get; set; }
        public ArgumentList3 argumentList { get; set; }
    }

    public class Group3
    {
        public Cmd13 cmd_1 { get; set; }
    }

    public class Arguments5
    {
        public string NewMode { get; set; }
    }

    public class Cmd14
    {
        public string label { get; set; }
        public string serviceId { get; set; }
        public string action { get; set; }
        public Arguments5 arguments { get; set; }
    }

    public class Arguments6
    {
        public string NewMode { get; set; }
    }

    public class Cmd22
    {
        public string label { get; set; }
        public string serviceId { get; set; }
        public string action { get; set; }
        public Arguments6 arguments { get; set; }
    }

    public class Group4
    {
        public Cmd14 cmd_1 { get; set; }
        public Cmd22 cmd_2 { get; set; }
    }

    public class Arguments7
    {
        public string newTargetValue { get; set; }
    }

    public class Cmd15
    {
        public string label { get; set; }
        public string serviceId { get; set; }
        public string action { get; set; }
        public Arguments7 arguments { get; set; }
    }

    public class Arguments8
    {
        public string newTargetValue { get; set; }
    }

    public class Cmd23
    {
        public string label { get; set; }
        public string serviceId { get; set; }
        public string action { get; set; }
        public Arguments8 arguments { get; set; }
    }

    public class Group5
    {
        public Cmd15 cmd_1 { get; set; }
        public Cmd23 cmd_2 { get; set; }
    }

    public class SceneList
    {
        public Group1 group_1 { get; set; }
        public Group2 group_2 { get; set; }
        public Group3 group_3 { get; set; }
        public Group4 group_4 { get; set; }
        public Group5 group_5 { get; set; }
    }

    public class DisplayStatus
    {
        public string Service { get; set; }
        public string Variable { get; set; }
        public string MinValue { get; set; }
        public string MaxValue { get; set; }
    }

    public class DocUrl
    {
        public int doc_language { get; set; }
        public int doc_manual { get; set; }
        public int doc_version { get; set; }
        public int doc_platform { get; set; }
        public string doc_page { get; set; }
    }

    public class StaticData
    {
        public string default_icon { get; set; }
        public string inScene { get; set; }
        public int ToggleButton { get; set; }
        public List<Tab> Tabs { get; set; }
        public List<object> eventList2 { get; set; }
        public string device_type { get; set; }
        public string device_json { get; set; }
        public List<object> state_icons { get; set; }
        public string x { get; set; }
        public string y { get; set; }
        public SceneList sceneList { get; set; }
        public string iconText { get; set; }
        public string username { get; set; }
        public string password { get; set; }
        public DisplayStatus DisplayStatus { get; set; }
        public string DeviceType { get; set; }
        public string flashicon { get; set; }
        public string imgIconBody { get; set; }
        public string imgIconDimmable { get; set; }
        public string imgIconTurnable { get; set; }
        public string imgIconMin { get; set; }
        public string imgIconMax { get; set; }
        public string halloIconsDir { get; set; }
        public DocUrl doc_url { get; set; }
        public string imgicon { get; set; }
        public int? plugin_id { get; set; }
    }

    public class Label2
    {
        public string lang_tag { get; set; }
        public string text { get; set; }
    }

    public class DisplayStatus2
    {
    }

    public class Label3
    {
        public string lang_tag { get; set; }
        public string text { get; set; }
    }

    public class Tab2
    {
        public Label3 Label { get; set; }
        public string Position { get; set; }
        public string TabType { get; set; }
        public string ScriptName { get; set; }
        public string Function { get; set; }
        public string Permission { get; set; }
        public List<int?> Parameters { get; set; }
    }

    public class HelpUrl
    {
        public string Function { get; set; }
        public List<string> Parameters { get; set; }
    }

    public class SetupDevice
    {
        public string DeviceType { get; set; }
        public string name { get; set; }
        public Label2 Label { get; set; }
        public string Toolbox { get; set; }
        public string Permission { get; set; }
        public string Icon { get; set; }
        public DisplayStatus2 DisplayStatus { get; set; }
        public List<Tab2> Tabs { get; set; }
        public HelpUrl help_url { get; set; }
    }

    public class Label4
    {
        public string lang_tag { get; set; }
        public string text { get; set; }
    }

    public class CategoryFilter
    {
        public int id { get; set; }
        public List<object> categories { get; set; }
        public Label4 Label { get; set; }
    }

    public class HomeAutomationControllerDto
    {
        public List<Device> devices { get; set; }
        public List<Room> rooms { get; set; }
        public List<Scene> scenes { get; set; }
        public List<Section> sections { get; set; }
        public string timezone { get; set; }
        public string firmware_version { get; set; }
        public List<object> ExtraLuaFiles { get; set; }
        public string ServerBackup { get; set; }
        public int net_pnp { get; set; }
        public string UpnpDiscoveryInterval { get; set; }
        public List<string> downtime { get; set; }
        public WeatherSettings weatherSettings { get; set; }
        public string setup_wizard_finished { get; set; }
        public bool shouldHelpOverlayBeHidden { get; set; }
        public string breach_delay { get; set; }
        public List<IpRequest> ip_requests { get; set; }
        public List<InstalledPlugins2> InstalledPlugins2 { get; set; }
        public string mode_change_delay { get; set; }
        public string ui_lang { get; set; }
        public string country_pk { get; set; }
        public string latitude { get; set; }
        public string longitude { get; set; }
        public string Region_description { get; set; }
        public string Country_description { get; set; }
        public string City_description { get; set; }
        public string currency { get; set; }
        public string KwhPrice { get; set; }
        public string ModeSetting { get; set; }
        public string zwave_heal { get; set; }
        public string Scene_Num_Next { get; set; }
        public string EnableUPnP { get; set; }
        public string sync_kit { get; set; }
        public string mode_change_time { get; set; }
        public string mode_change_mode { get; set; }
        public string Mode { get; set; }
        public string ergy_user { get; set; }
        public List<object> users_settings { get; set; }
        public List<object> InstalledPlugins { get; set; }
        public List<object> PluginSettings { get; set; }
        public string Device_Num_Next { get; set; }
        public List<User> users { get; set; }
        public string BuildVersion { get; set; }
        public string SvnVersion { get; set; }
        public string model { get; set; }
        public string local_udn { get; set; }
        public string Server_Device { get; set; }
        public string Server_Device_Alt { get; set; }
        public string TemperatureFormat { get; set; }
        public string gmt_offset { get; set; }
        public string skin { get; set; }
        public string PK_AccessPoint { get; set; }
        public string RA_Server { get; set; }
        public string RA_Server_Back { get; set; }
        public int ir { get; set; }
        public string DataVersion_Static { get; set; }
        public string DataVersion_Changed { get; set; }
        public string PluginsSynced { get; set; }
        public ZwaveBackup zwave_backup { get; set; }
        public string PluginsSyncedMMS { get; set; }
        public string homeStateAnyUserAtHome { get; set; }
        public string awayStateAllUserNotAtHome { get; set; }
        public string device_sync { get; set; }
        public string scene_sync { get; set; }
        public string room_sync { get; set; }
        public string DeviceSync { get; set; }
        public List<Usergeofence> usergeofences { get; set; }
        public int UnassignedDevices { get; set; }
        public int AutomationDevices { get; set; }
        public string LuaUPnPAlive { get; set; }
        public int DataVersion { get; set; }
        public int LoadTime { get; set; }
        public int Using_2G { get; set; }
        public List<StaticData> static_data { get; set; }
        public List<object> overview_tabs { get; set; }
        public List<SetupDevice> SetupDevices { get; set; }
        public List<CategoryFilter> category_filter { get; set; }
    }
}