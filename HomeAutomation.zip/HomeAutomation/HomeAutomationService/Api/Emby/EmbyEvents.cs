﻿using MediaBrowser.Model.Entities;
using MediaBrowser.Model.Session;
using MediaBrowser.Model.Events;
using MediaBrowser.Model.ApiClient;
using MediaBrowser.Model.Querying;
using System;
using System.IO;
using System.Linq;
using HomeAutomationService.Helpers;


namespace HomeAutomationService.Emby
{
    public class EmbyEvents
    {
        private static string t { get; set; }

        public static async void C_SessionsUpdated(object sender, GenericEventArgs<SessionUpdatesEventArgs> e)
        {
            //var sessionText = "";

            SessionInfoDto[] sessions = null;

            try
            {
                sessions = await EmbyApi.EmbyClient.GetClientSessionsAsync(new SessionQuery() { });
            }
            catch { }
            if (sessions == null) return;

            foreach (var session in sessions.Where(s => s.NowPlayingItem != null || s.NowViewingItem != null))
            {
                BaseItemInfo nvi = null;
                if (session.NowViewingItem != null)
                {
                    nvi = session.NowViewingItem;
                }

                if (session.NowPlayingItem != null)
                {
                    nvi = session.NowPlayingItem;
                }

               // sessionText = sessionText + string.Format("Emby {0} Playing: {1}", nvi.Type, nvi.Name);

               if(!Equals(t, session.NowPlayingItem.Name))
                { 
                    
                    ConsoleHelper.Write(string.Format("{0}:   {1}", session.UserName, session.NowPlayingItem.Name), ConsoleHelper.AppMessage.Emby);
                    
                    t = session.NowPlayingItem.Name;
                }
            }
        }
    }
}
