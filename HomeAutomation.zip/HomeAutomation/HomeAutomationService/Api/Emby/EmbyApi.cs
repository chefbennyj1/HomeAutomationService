﻿using System;

using MediaBrowser.Model.Logging;
using HomeAutomationService.Helpers;

using Emby.ApiClient;
using Emby.ApiClient.Cryptography;
using Emby.ApiClient.WebSocket;

namespace HomeAutomationService.Emby
{
    internal class EmbyApi 
    {
        public static ApiClient EmbyClient { get; set; }
        private static ApiClient CreateEmbyClient(ServerInfo info)
        {
            try
            {
                return new ApiClient(new NullLogger(), info.Address, "Home Automation Services",
                    new Device
                    {
                        DeviceId = "01",
                        DeviceName = "Home Automation Services"
                    }, "1.0", new CryptographyProvider());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return null;
        }

        private static void C_WebSocketConnected(object sender, EventArgs e)
        {
            EmbyClient.StartReceivingSessionUpdates(2000);
            EmbyClient.SessionsUpdated += EmbyEvents.C_SessionsUpdated;
        }
        
        public  static async void BuildEmbyClient()
        {
            EmbyClient = CreateEmbyClient(EmbyServerLocator.ServerProtocolAddress());
            await EmbyClient.AuthenticateUserAsync("Admin", "Du944hqk&");
            EmbyClient.WebSocketConnected += C_WebSocketConnected;
            EmbyClient.OpenWebSocket(); 
            if (EmbyClient.AccessToken != null) ConsoleHelper.Write("Emby Server Connected", ConsoleHelper.AppMessage.Emby);
        }
    }
}
