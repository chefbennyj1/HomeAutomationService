﻿using System.Collections.Generic;
using System.Linq;
using Emby.ApiClient;
using MediaBrowser.Model.Querying;
using MediaBrowser.Model.Session;

namespace HomeAutomationService.Emby
{
    // ReSharper disable InconsistentNaming
    // ReSharper disable ClassNeverInstantiated.Global
    // ReSharper disable UnusedMember.Global
    // ReSharper disable UnusedAutoPropertyAccessor.Global
    // ReSharper disable TooManyArguments
    // ReSharper disable MaximumChainedReferences

    public class EmbyMessenger
    {
        //private static async void DisplayMessage(ApiClient client, SessionInfoDto e,
        //    string header, string text)
        //{
        //    var args = new Dictionary<string, string> {{"Header", header}, {"Text", text}, {"TimeoutMs", "5000"}};

        //    await client.SendCommandAsync(e.Id,
        //        new GeneralCommand
        //        {
        //            Arguments = args,
        //            ControllingUserId = null,
        //            Name = "DisplayMessage"
        //        });
        //}

        //public static async void BroadcastMessageEmbyClients(string Header, string Text)
        //{
        //    SessionInfoDto[] sessions = await EmbyApi.EmbyClient.GetClientSessionsAsync(new SessionQuery());
        //    foreach (SessionInfoDto session in sessions.Where(session => session.UserName != null &&
        //                                                                 !session.UserName.ToLower()
        //                                                                     .Contains("mom and dad")))
        //    {
        //        DisplayMessage(EmbyApi.EmbyClient, session, Header, Text);
        //    }
        //}
    }
}