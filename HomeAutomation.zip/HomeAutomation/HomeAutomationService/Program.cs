﻿using System;
using System.ComponentModel;
using HomeAutomationService.Emby;
using HomeAutomationService.Vera;
using HomeAutomationService.Xbox;
using HomeAutomationService.ComputerDisplay;
using Microsoft.Owin.Hosting;
using HomeAutomationService.Helpers;

namespace HomeAutomationService
{
    // ReSharper disable once ClassNeverInstantiated.Global
    public class Program
    {      
       
        public static BackgroundWorker ControlFireplace { get; private set; }
              
        [STAThread]
        private static void Main()
        {
            Console.Write(ConsoleHelper.CreateConsoleHeader());

            //ImageHelper.GetCameraImageFromUrl("http://192.168.2.28//tmpfs/auto.jpg%3F");
            //if (DetectFace.Detect(new Image<Bgr, byte>("full_body_test.jpg")))
            //{
            //    Console.WriteLine("FaceDetected");
            //}
            //else
            //{
            //    Console.WriteLine("No Face");
            //}

            //Emby Service
            EmbyApi.BuildEmbyClient();

            // Set device states
            ComputerDisplayController.Controller(ComputerDisplayController.DisplayControl.ON);
            Model.DeviceStates["Computer Display"] = true;

            // Xbox Service
            //XboxOneApi.BuildXboxOneClient(CreateStateMonitor: true);

            //Vera Home Automation Service
            VeraApi.BuildVeraClient(CreateStateMonitor: true);

            // Fireplace Controller
            ControlFireplace = new BackgroundWorker();
            ControlFireplace.DoWork += InfraredEvents.FireplaceOn;

            //Alexa Endpoint Service
            const string baseAddress = "http://192.168.2.104:9925/";
            using (WebApp.Start<Startup>(baseAddress))
            {
                //var io = new RoutineAI();

               //Editor.EditDataset(RoutineAI.LoadTrainningData());
                ConsoleHelper.Write("Amazon Alexa Endpoint Connected", ConsoleHelper.AppMessage.Alexa);

                Console.ReadLine();
            }
        }
    }
}